/* DO NOT EDIT! GENERATED AUTOMATICALLY! */
#define PREFIX "/usr/local"
#define SYSCONFDIR "/usr/local/etc"
#define GEARMAND_CONFIG "/usr/local/etc/gearmand.conf"
#define LOCALSTATEDIR "/usr/local/var"
#define GEARMAND_PID "/usr/local/var/gearmand.pid"
